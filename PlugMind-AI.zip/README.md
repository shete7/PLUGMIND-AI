# 🚀 PlugMind AI – Portable USB AI Assistant  
### Made by Shreyas Shete  

PlugMind AI is a **powerful, portable AI assistant** that runs directly from a USB drive. It allows you to chat with AI, search local files, take voice commands, and even auto-update itself when connected to the internet.  

## **🔹 Features**
- **💬 AI Chatbot** – Ask anything and get responses from an AI model.  
- **🗣 Voice Control** – Speak commands instead of typing.  
- **🔍 File Search** – Search for local files using voice commands.  
- **📡 Works Online & Offline** – Uses open-source AI models when offline.  
- **🛠 Auto-Updates** – Automatically checks for updates from GitHub and installs them.  
- **🎛 Customizable Modes** – Choose between **Light** and **Heavy AI models** based on USB storage.  
- **🎙 Voice Mode Toggle** – Turn voice input **on/off** as needed.  

## **🛠 Installation Guide**
### **1️⃣ Download and Install**
1. **Clone the repository**:  
   ```bash
   git clone https://github.com/shete7/PlugMind-AI.git
   ```
2. **Copy files** to your USB drive.  
3. **Install required dependencies**:  
   ```bash
   pip install -r requirements.txt
   ```

### **2️⃣ Running PlugMind AI**
- **To start PlugMind AI**, open a terminal and run:  
  ```bash
  python assistant.py
  ```
- **To check for updates**, run:  
  ```bash
  python update.py
  ```

## **📝 License**
This project is **open-source** and free to use. Feel free to contribute!  

## **📩 Contact & Support**
For issues or feature requests, open a **GitHub Issue**.  

**Made by Shreyas Shete** ✨  
